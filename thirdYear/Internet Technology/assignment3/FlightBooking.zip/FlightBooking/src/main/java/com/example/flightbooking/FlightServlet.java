package com.example.flightbooking;

import com.example.dao.OfferDAO;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet(name = "FlightServlet", value = "/flight-servlet")
public class FlightServlet extends HttpServlet {
    private String message;

    public void init() {
        message = "Hello World!";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        OfferDAO offerDAO = new OfferDAO(request.getServletContext());

        System.out.println(offerDAO.readAllOffers());


        getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
    }

    public void destroy() {
    }
}